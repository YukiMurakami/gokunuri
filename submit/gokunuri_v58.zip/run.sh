#/bin/bash

./gokunuri
